package com.task.product.entities;

public enum STATUS {
    ACTIVE,
    INACTIVE
}
