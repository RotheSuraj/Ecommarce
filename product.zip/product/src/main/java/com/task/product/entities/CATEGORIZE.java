package com.task.product.entities;

public enum CATEGORIZE{
    ELECTRONICS,
    SHOES,
    CLOTHES
} 

